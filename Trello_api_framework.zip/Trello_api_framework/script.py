
import os
from pathlib import Path

# Create directory structure
base_dir = Path("trello_api_automation")
directories = [
    base_dir / "config",
    base_dir / "api_clients",
    base_dir / "tests",
    base_dir / "utils",
    base_dir / "logs"
]

for directory in directories:
    directory.mkdir(parents=True, exist_ok=True)
    
print("Directory structure created successfully!")
print("\nCreated directories:")
for dir in directories:
    print(f"  - {dir}")
