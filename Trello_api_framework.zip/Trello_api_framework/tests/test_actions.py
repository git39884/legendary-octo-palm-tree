import pytest
from api_clients.actions_api import ActionsAPI


class TestActionsAPI:
    """Test cases for Trello Actions API"""

    @pytest.fixture(scope="class")
    def actions_client(self):
        """Fixture to create ActionsAPI client"""
        client = ActionsAPI()
        yield client
        client.close_session()

    def test_get_action_valid_id(self, actions_client):
        """Test getting an action with valid ID"""
        # Replace with a valid action ID from your Trello board
        action_id = "68d12ba58d1d272a32471fbd"

        response = actions_client.get_action(action_id)

        # Assertions
        assert response is not None
        assert 'id' in response
        assert response['id'] == action_id
        assert 'type' in response
        assert 'date' in response
        print(f"Action Type: {response.get('type')}")
        print(f"Action Date: {response.get('date')}")

    def test_get_action_with_specific_fields(self, actions_client):
        """Test getting an action with specific fields"""
        action_id = "68d12ba58d1d272a32471fbd"

        # Request only specific fields
        params = {
            'fields': 'id,type,date',
            'display': 'true'
        }

        response = actions_client.get_action(action_id, params=params)

        assert response is not None
        assert 'id' in response
        assert 'type' in response
        assert 'date' in response

    def test_get_action_board(self, actions_client):
        """Test getting the board associated with an action"""
        action_id = "68d12ba58d1d272a32471fbd"

        response = actions_client.get_action_board(action_id)

        assert response is not None
        assert 'id' in response
        assert 'name' in response
        print(f"Board Name: {response.get('name')}")

    def test_get_action_card(self, actions_client):
        """Test getting the card associated with an action"""
        action_id = "68d12ba58d1d272a32471fbd"

        response = actions_client.get_action_card(action_id, fields='id,name,desc')

        assert response is not None
        assert 'id' in response
        assert 'name' in response
        print(f"Card Name: {response.get('name')}")

    def test_get_action_member_creator(self, actions_client):
        """Test getting the member who created an action"""
        action_id = "68d12ba58d1d272a32471fbd"

        response = actions_client.get_action_member_creator(
            action_id,
            fields='id,username,fullName'
        )

        assert response is not None
        assert 'id' in response
        assert 'username' in response
        print(f"Creator: {response.get('fullName')}")

    def test_list_action_reactions(self, actions_client):
        """Test listing reactions for an action"""
        action_id = "68d12ba58d1d272a32471fbd"

        response = actions_client.list_action_reactions(action_id)

        assert response is not None
        print(f"Reactions: {response}")

    @pytest.mark.parametrize("field", ["type", "date", "data"])
    def test_get_action_specific_field(self, actions_client, field):
        """Parameterized test for getting specific action fields"""
        action_id = "68d12ba58d1d272a32471fbd"

        response = actions_client.get_action_field(action_id, field)

        assert response is not None
        print(f"Field '{field}' value: {response}")
