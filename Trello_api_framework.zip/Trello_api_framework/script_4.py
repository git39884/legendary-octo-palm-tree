
# Create api_clients/actions_api.py
actions_api_py = """from typing import Optional, Dict, Any
from api_clients.base_api import BaseAPI

class ActionsAPI(BaseAPI):
    \"\"\"API client for Trello Actions endpoints\"\"\"
    
    def __init__(self):
        super().__init__()
        self.endpoint_base = "actions"
    
    def get_action(self, action_id: str, params: Optional[Dict] = None) -> Dict[str, Any]:
        \"\"\"
        Get an Action by ID
        
        Args:
            action_id: The ID of the action
            params: Optional query parameters (display, entities, fields, etc.)
        
        Returns:
            Dictionary containing action details
        \"\"\"
        endpoint = f"{self.endpoint_base}/{action_id}"
        return self.get(endpoint, params=params)
    
    def update_action(self, action_id: str, text: str) -> Dict[str, Any]:
        \"\"\"
        Update a specific Action (only comment actions can be updated)
        
        Args:
            action_id: The ID of the action to update
            text: New text for the comment
        
        Returns:
            Dictionary containing updated action details
        \"\"\"
        endpoint = f"{self.endpoint_base}/{action_id}"
        params = {'text': text}
        return self.put(endpoint, params=params)
    
    def delete_action(self, action_id: str) -> Dict[str, Any]:
        \"\"\"
        Delete a specific action (only comment actions can be deleted)
        
        Args:
            action_id: The ID of the action to delete
        
        Returns:
            Empty dictionary on success
        \"\"\"
        endpoint = f"{self.endpoint_base}/{action_id}"
        return self.delete(endpoint)
    
    def get_action_field(self, action_id: str, field: str) -> Dict[str, Any]:
        \"\"\"
        Get a specific property of an action
        
        Args:
            action_id: The ID of the action
            field: The field to retrieve (e.g., 'type', 'date', 'data')
        
        Returns:
            Dictionary containing the field value
        \"\"\"
        endpoint = f"{self.endpoint_base}/{action_id}/{field}"
        return self.get(endpoint)
    
    def get_action_board(self, action_id: str, 
                        fields: Optional[str] = None) -> Dict[str, Any]:
        \"\"\"
        Get the Board for an Action
        
        Args:
            action_id: The ID of the action
            fields: Optional comma-separated list of board fields to return
        
        Returns:
            Dictionary containing board details
        \"\"\"
        endpoint = f"{self.endpoint_base}/{action_id}/board"
        params = {'fields': fields} if fields else None
        return self.get(endpoint, params=params)
    
    def get_action_card(self, action_id: str, 
                       fields: Optional[str] = None) -> Dict[str, Any]:
        \"\"\"
        Get the Card for an Action
        
        Args:
            action_id: The ID of the action
            fields: Optional comma-separated list of card fields to return
        
        Returns:
            Dictionary containing card details
        \"\"\"
        endpoint = f"{self.endpoint_base}/{action_id}/card"
        params = {'fields': fields} if fields else None
        return self.get(endpoint, params=params)
    
    def get_action_list(self, action_id: str, 
                       fields: Optional[str] = None) -> Dict[str, Any]:
        \"\"\"
        Get the List for an Action
        
        Args:
            action_id: The ID of the action
            fields: Optional comma-separated list of list fields to return
        
        Returns:
            Dictionary containing list details
        \"\"\"
        endpoint = f"{self.endpoint_base}/{action_id}/list"
        params = {'fields': fields} if fields else None
        return self.get(endpoint, params=params)
    
    def get_action_member(self, action_id: str, 
                         fields: Optional[str] = None) -> Dict[str, Any]:
        \"\"\"
        Gets the member of an action (not the creator)
        
        Args:
            action_id: The ID of the action
            fields: Optional comma-separated list of member fields to return
        
        Returns:
            Dictionary containing member details
        \"\"\"
        endpoint = f"{self.endpoint_base}/{action_id}/member"
        params = {'fields': fields} if fields else None
        return self.get(endpoint, params=params)
    
    def get_action_member_creator(self, action_id: str, 
                                  fields: Optional[str] = None) -> Dict[str, Any]:
        \"\"\"
        Get the Member who created the Action
        
        Args:
            action_id: The ID of the action
            fields: Optional comma-separated list of member fields to return
        
        Returns:
            Dictionary containing member creator details
        \"\"\"
        endpoint = f"{self.endpoint_base}/{action_id}/memberCreator"
        params = {'fields': fields} if fields else None
        return self.get(endpoint, params=params)
    
    def get_action_organization(self, action_id: str, 
                               fields: Optional[str] = None) -> Dict[str, Any]:
        \"\"\"
        Get the Organization of an Action
        
        Args:
            action_id: The ID of the action
            fields: Optional comma-separated list of organization fields to return
        
        Returns:
            Dictionary containing organization details
        \"\"\"
        endpoint = f"{self.endpoint_base}/{action_id}/organization"
        params = {'fields': fields} if fields else None
        return self.get(endpoint, params=params)
    
    def list_action_reactions(self, action_id: str, 
                             member: Optional[bool] = None,
                             emoji: Optional[bool] = None) -> Dict[str, Any]:
        \"\"\"
        List reactions for an action
        
        Args:
            action_id: The ID of the action
            member: Whether to include member data
            emoji: Whether to include emoji data
        
        Returns:
            Dictionary containing reactions list
        \"\"\"
        endpoint = f"{self.endpoint_base}/{action_id}/reactions"
        params = {}
        if member is not None:
            params['member'] = str(member).lower()
        if emoji is not None:
            params['emoji'] = str(emoji).lower()
        return self.get(endpoint, params=params if params else None)
    
    def add_reaction(self, action_id: str, reaction_data: Dict[str, str]) -> Dict[str, Any]:
        \"\"\"
        Adds a new reaction to an action
        
        Args:
            action_id: The ID of the action
            reaction_data: Dictionary with reaction details (shortName, skinVariation, etc.)
        
        Returns:
            Dictionary containing created reaction details
        \"\"\"
        endpoint = f"{self.endpoint_base}/{action_id}/reactions"
        return self.post(endpoint, json_data=reaction_data)
    
    def get_reaction(self, action_id: str, reaction_id: str) -> Dict[str, Any]:
        \"\"\"
        Get information for a reaction
        
        Args:
            action_id: The ID of the action
            reaction_id: The ID of the reaction
        
        Returns:
            Dictionary containing reaction details
        \"\"\"
        endpoint = f"{self.endpoint_base}/{action_id}/reactions/{reaction_id}"
        return self.get(endpoint)
    
    def delete_reaction(self, action_id: str, reaction_id: str) -> Dict[str, Any]:
        \"\"\"
        Deletes a reaction
        
        Args:
            action_id: The ID of the action
            reaction_id: The ID of the reaction to delete
        
        Returns:
            Empty dictionary on success
        \"\"\"
        endpoint = f"{self.endpoint_base}/{action_id}/reactions/{reaction_id}"
        return self.delete(endpoint)
    
    def get_reactions_summary(self, action_id: str) -> Dict[str, Any]:
        \"\"\"
        List a summary of all reactions for an action
        
        Args:
            action_id: The ID of the action
        
        Returns:
            Dictionary containing reactions summary
        \"\"\"
        endpoint = f"{self.endpoint_base}/{action_id}/reactionsSummary"
        return self.get(endpoint)
"""

with open("trello_api_automation/api_clients/actions_api.py", "w") as f:
    f.write(actions_api_py)

print("Created: api_clients/actions_api.py")
