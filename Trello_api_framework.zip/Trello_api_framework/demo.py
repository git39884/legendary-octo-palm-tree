"""
Example usage script for Trello API automation framework
Replace 'your_action_id_here' with actual action IDs from your Trello board
"""

from api_clients.actions_api import ActionsAPI


def main():
    # Initialize the Actions API client
    print("Initializing Trello Actions API client...")
    client = ActionsAPI()

    try:
        # Example 1: Get an action by ID
        print("\n" + "=" * 50)
        print("Example 1: Get Action Details")
        print("=" * 50)
        action_id = "68e47b97753b8de174f55c28"  # Replace with actual action ID

        action = client.get_action(action_id)
        print(f"Action ID: {action.get('id')}")
        print(f"Action Type: {action.get('type')}")
        print(f"Action Date: {action.get('date')}")

        # Example 2: Get board associated with action
        print("\n" + "=" * 50)
        print("Example 2: Get Board for Action")
        print("=" * 50)

        board = client.get_action_board(action_id, fields='id,name,url')
        print(f"Board ID: {board.get('id')}")
        print(f"Board Name: {board.get('name')}")
        print(f"Board URL: {board.get('url')}")

        # Example 3: Get card associated with action
        print("\n" + "=" * 50)
        print("Example 3: Get Card for Action")
        print("=" * 50)

        card = client.get_action_card(action_id, fields='id,name,desc')
        print(f"Card ID: {card.get('id')}")
        print(f"Card Name: {card.get('name')}")
        print(f"Card Description: {card.get('desc')}")

        # Example 4: Get member creator
        print("\n" + "=" * 50)
        print("Example 4: Get Member Creator")
        print("=" * 50)

        member = client.get_action_member_creator(action_id, fields='id,username,fullName')
        print(f"Creator ID: {member.get('id')}")
        print(f"Creator Username: {member.get('username')}")
        print(f"Creator Full Name: {member.get('fullName')}")

        # Example 5: Get specific field
        print("\n" + "=" * 50)
        print("Example 5: Get Specific Action Field")
        print("=" * 50)

        action_type = client.get_action_field(action_id, 'type')
        print(f"Action Type Field: {action_type}")

        print("\n" + "=" * 50)
        print("All examples completed successfully!")
        print("=" * 50)

    except Exception as e:
        print(f"\nError occurred: {str(e)}")
        print("\nPlease ensure:")
        print("1. You have set TRELLO_API_KEY and TRELLO_API_TOKEN in .env file")
        print("2. You have replaced 'your_action_id_here' with actual action ID")
        print("3. You have access to the Trello board")

    finally:
        # Always close the session
        print("\nClosing API session...")
        client.close_session()
        print("Done!")


if __name__ == "__main__":
    main()
