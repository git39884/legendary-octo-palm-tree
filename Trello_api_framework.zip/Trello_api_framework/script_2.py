
# Create utils/__init__.py
utils_init = """# Utils package initialization
"""

with open("trello_api_automation/utils/__init__.py", "w") as f:
    f.write(utils_init)

print("Created: utils/__init__.py")

# Create utils/logger.py
logger_py = """import logging
from pathlib import Path
from datetime import datetime
from config.config import Config

class APILogger:
    \"\"\"Logger utility for API requests and responses\"\"\"
    
    def __init__(self, name=__name__):
        self.logger = logging.getLogger(name)
        self.logger.setLevel(getattr(logging, Config.LOG_LEVEL))
        
        # Create logs directory if it doesn't exist
        log_dir = Path(__file__).parent.parent / "logs"
        log_dir.mkdir(exist_ok=True)
        
        # File handler
        log_file = log_dir / f"api_test_{datetime.now().strftime('%Y%m%d')}.log"
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(logging.DEBUG)
        
        # Console handler
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        
        # Formatter
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)
        
        # Add handlers if not already added
        if not self.logger.handlers:
            self.logger.addHandler(file_handler)
            self.logger.addHandler(console_handler)
    
    def log_request(self, method, url, **kwargs):
        \"\"\"Log API request details\"\"\"
        self.logger.info(f"Request: {method.upper()} {url}")
        if 'params' in kwargs:
            # Don't log sensitive auth params
            safe_params = {k: v for k, v in kwargs['params'].items() 
                          if k not in ['key', 'token']}
            if safe_params:
                self.logger.debug(f"Query Params: {safe_params}")
        if 'json' in kwargs:
            self.logger.debug(f"Request Body: {kwargs['json']}")
    
    def log_response(self, response):
        \"\"\"Log API response details\"\"\"
        self.logger.info(f"Response: Status Code {response.status_code}")
        self.logger.debug(f"Response Body: {response.text[:500]}")  # Log first 500 chars
    
    def log_error(self, error):
        \"\"\"Log error details\"\"\"
        self.logger.error(f"Error occurred: {str(error)}")
"""

with open("trello_api_automation/utils/logger.py", "w") as f:
    f.write(logger_py)

print("Created: utils/logger.py")
