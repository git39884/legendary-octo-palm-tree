import os
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

class Config:
    """Configuration class for Trello API"""

    # Base URL for Trello API
    BASE_URL = "https://api.trello.com/1"

    # Authentication credentials
    API_KEY = os.getenv('TRELLO_API_KEY', 'your_api_key_here')
    API_TOKEN = os.getenv('TRELLO_API_TOKEN', 'your_api_token_here')

    # Request timeout in seconds
    TIMEOUT = 30

    # Retry configuration
    MAX_RETRIES = 3
    RETRY_DELAY = 2

    # Logging configuration
    LOG_LEVEL = "INFO"
    LOG_FILE = Path(__file__).parent.parent / "logs" / "api_test.log"

    @classmethod
    def get_auth_params(cls):
        """Returns authentication parameters as dictionary"""
        return {
            'key': cls.API_KEY,
            'token': cls.API_TOKEN
        }

    @classmethod
    def validate_config(cls):
        """Validates that required configuration is present"""
        if cls.API_KEY == 'your_api_key_here' or not cls.API_KEY:
            raise ValueError("TRELLO_API_KEY is not configured. Please set it in .env file")
        if cls.API_TOKEN == 'your_api_token_here' or not cls.API_TOKEN:
            raise ValueError("TRELLO_API_TOKEN is not configured. Please set it in .env file")
        return True
