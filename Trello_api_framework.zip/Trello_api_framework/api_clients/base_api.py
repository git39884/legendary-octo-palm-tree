import requests
import time
from typing import Optional, Dict, Any
from config.config import Config
from utils.logger import APILogger

class BaseAPI:
    """Base API client with common functionality"""

    def __init__(self):
        self.base_url = Config.BASE_URL
        self.session = requests.Session()
        self.logger = APILogger(self.__class__.__name__)

        # Set default headers
        self.session.headers.update({
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        })

        # Validate configuration
        Config.validate_config()

    def _build_url(self, endpoint: str) -> str:
        """Build complete URL from endpoint"""
        return f"{self.base_url}/{endpoint.lstrip('/')}"

    def _add_auth_params(self, params: Optional[Dict] = None) -> Dict:
        """Add authentication parameters to request params"""
        auth_params = Config.get_auth_params()
        if params:
            auth_params.update(params)
        return auth_params

    def _handle_response(self, response: requests.Response) -> Dict[str, Any]:
        """Handle API response and raise exceptions for errors"""
        self.logger.log_response(response)

        try:
            response.raise_for_status()
            return response.json() if response.text else {}
        except requests.exceptions.HTTPError as e:
            self.logger.log_error(e)
            error_detail = {
                'status_code': response.status_code,
                'error_message': response.text,
                'url': response.url
            }
            raise Exception(f"HTTP Error: {error_detail}")
        except requests.exceptions.RequestException as e:
            self.logger.log_error(e)
            raise

    def _make_request(self, method: str, endpoint: str, 
                     params: Optional[Dict] = None,
                     json_data: Optional[Dict] = None,
                     retry: int = 0) -> Dict[str, Any]:
        """Make HTTP request with retry logic"""
        url = self._build_url(endpoint)
        params = self._add_auth_params(params)

        try:
            self.logger.log_request(method, url, params=params, json=json_data)

            response = self.session.request(
                method=method,
                url=url,
                params=params,
                json=json_data,
                timeout=Config.TIMEOUT
            )

            return self._handle_response(response)

        except requests.exceptions.RequestException as e:
            if retry < Config.MAX_RETRIES:
                self.logger.logger.warning(
                    f"Request failed, retrying ({retry + 1}/{Config.MAX_RETRIES})..."
                )
                time.sleep(Config.RETRY_DELAY)
                return self._make_request(method, endpoint, params, json_data, retry + 1)
            raise

    def get(self, endpoint: str, params: Optional[Dict] = None) -> Dict[str, Any]:
        """Make GET request"""
        return self._make_request('GET', endpoint, params=params)

    def post(self, endpoint: str, params: Optional[Dict] = None, 
             json_data: Optional[Dict] = None) -> Dict[str, Any]:
        """Make POST request"""
        return self._make_request('POST', endpoint, params=params, json_data=json_data)

    def put(self, endpoint: str, params: Optional[Dict] = None, 
            json_data: Optional[Dict] = None) -> Dict[str, Any]:
        """Make PUT request"""
        return self._make_request('PUT', endpoint, params=params, json_data=json_data)

    def delete(self, endpoint: str, params: Optional[Dict] = None) -> Dict[str, Any]:
        """Make DELETE request"""
        return self._make_request('DELETE', endpoint, params=params)

    def close_session(self):
        """Close the requests session"""
        self.session.close()
