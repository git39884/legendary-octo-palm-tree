# Trello API Automation Framework

A Python-based API automation framework for testing Trello REST APIs using the requests library.

## Features
- Clean architecture similar to Page Object Model for APIs
- Centralized configuration management
- Comprehensive logging for requests and responses
- Automatic retry mechanism for failed requests
- pytest integration for test execution
- Support for all Trello Actions API endpoints

## Setup Instructions

### 1. Get Trello API Credentials
1. Visit https://trello.com/power-ups/admin
2. Create a new Power-Up or select existing one
3. Navigate to API Key tab and generate API key
4. Get your token by visiting:
